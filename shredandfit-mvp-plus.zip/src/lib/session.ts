import { getIronSession } from "iron-session";
import { cookies } from "next/headers";

export const sessionOptions = {
  password: process.env.IRON_SESSION_PASSWORD!,
  cookieName: process.env.IRON_SESSION_COOKIE_NAME || "shredandfit_session",
  cookieOptions: { secure: process.env.NODE_ENV === "production" },
};

export type AppSession = { user?: { id: string; email: string; fullName?: string; role?: string; tier?: string } };

export async function getSession() {
  const s = await getIronSession<AppSession>(cookies(), sessionOptions);
  return s;
}
