import bcrypt from "bcryptjs";
import { prisma } from "./prisma";
import { getSession } from "./session";

export async function registerUser(email: string, password: string, fullName?: string) {
  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) throw new Error("Email already registered");
  const hash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({ data: { email, passwordHash: hash, fullName } });
  const session = await getSession();
  session.user = { id: user.id, email: user.email, fullName: user.fullName ?? undefined, role: user.role, tier: user.subscriptionTier };
  await session.save();
  return user;
}

export async function loginUser(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new Error("Invalid credentials");
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) throw new Error("Invalid credentials");
  const session = await getSession();
  session.user = { id: user.id, email: user.email, fullName: user.fullName ?? undefined, role: user.role, tier: user.subscriptionTier };
  await session.save();
  return user;
}

export async function logoutUser() {
  const s = await getSession();
  await s.destroy();
}
