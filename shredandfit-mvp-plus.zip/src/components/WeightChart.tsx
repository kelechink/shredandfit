'use client';
import React, { useMemo } from 'react';
import { ResponsiveContainer, ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Brush, ReferenceLine } from 'recharts';

type Point = { date: string; weightKg: number; steps?: number; sleepH?: number };

export default function WeightChart({ data, goalWeightKg, heightCm, showSteps=true }:{ data: Point[]; goalWeightKg?: number; heightCm?: number; showSteps?: boolean }) {
  const prepared = useMemo(() => {
    const d = [...data].sort((a,b)=> new Date(a.date).getTime() - new Date(b.date).getTime());
    const window = 7;
    const weights = d.map(p => p.weightKg ?? null) as (number|null)[];
    const ma = weights.map((_, i) => {
      const start = Math.max(0, i - window + 1);
      const slice = weights.slice(start, i + 1).filter((x): x is number => typeof x === 'number');
      if (!slice.length) return null;
      const avg = slice.reduce((s,v)=>s+v,0)/slice.length;
      return +avg.toFixed(1);
    });
    return d.map((p,i)=> ({ ...p, weightMA: ma[i] }));
  }, [data]);

  const computeBMI = (kg?: number|null) => {
    if (!kg || !heightCm) return null;
    const m = heightCm/100;
    return +(kg/(m*m)).toFixed(1);
  };

  return (
    <div style={{ width: '100%', height: 360 }}>
      <ResponsiveContainer>
        <ComposedChart data={prepared} margin={{ top: 10, right: 24, left: 12, bottom: 10 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" minTickGap={18} />
          <YAxis yAxisId="left" tickFormatter={(v)=>`${v} kg`} />
          {showSteps && <YAxis yAxisId="right" orientation="right" />}
          <Tooltip formatter={(val:any, name:any)=>{
            if (name==='weightKg') return [`${val} kg${computeBMI(val)?` (BMI ${computeBMI(val)})`:''}`, 'Weight'];
            if (name==='weightMA') return [`${val} kg`, '7d Avg'];
            if (name==='steps') return [val, 'Steps'];
            if (name==='sleepH') return [`${val} h`, 'Sleep'];
            return [val, name];
          }} />
          <Legend />
          {goalWeightKg && <ReferenceLine yAxisId="left" y={goalWeightKg} strokeDasharray="4 4" label={{ value: `Goal ${goalWeightKg} kg`, position: 'right' }} />}
          {showSteps && <Bar yAxisId="right" dataKey="steps" name="Steps" opacity={0.5} />}
          <Line yAxisId="left" type="monotone" dataKey="weightKg" name="Weight" dot={false} strokeWidth={2} />
          <Line yAxisId="left" type="monotone" dataKey="weightMA" name="7d Avg" strokeDasharray="5 5" dot={false} />
          <Brush dataKey="date" height={24} travellerWidth={10} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
