'use client';
import { useState } from 'react';

export default function Signup() {
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [fullName,setFullName]=useState(''); const [msg,setMsg]=useState('');
  async function submit(e:any){ e.preventDefault(); setMsg(''); const r=await fetch('/api/auth/signup',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,fullName})}); const j=await r.json(); if(!r.ok){setMsg(j.error||'Error');return;} window.location.href='/app'; }
  return (<div className="max-w-md mx-auto bg-white border rounded-2xl p-6"><h1 className="text-xl font-semibold">Create your account</h1><form onSubmit={submit} className="grid gap-3 mt-4"><input className="border rounded-lg px-3 py-2" placeholder="Full name" value={fullName} onChange={e=>setFullName(e.target.value)} /><input className="border rounded-lg px-3 py-2" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} /><input className="border rounded-lg px-3 py-2" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><button className="rounded-lg bg-black text-white px-4 py-2">Sign up</button>{msg && <div className="text-rose-600 text-sm">{msg}</div>}</form></div>);
}
