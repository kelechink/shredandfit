import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/session";

const proteins = ["eggs","chicken","turkey","fish","tuna","lean beef","beans","moi-moi","yogurt (unsweetened)"];
const carbs = ["ofada/brown rice","sweet potato","unripe plantain","oats","acha (fonio)","sorghum","whole-wheat bread","garri (small)"];
const soups = ["okra","ewedu","efo riro","edikaikong","tomato stew (light oil)"];
const snacks = ["boiled eggs","unsweetened yogurt","roasted groundnuts","kilishi (lean)","baked akara","tiger nuts","roasted chickpeas"];
const fruits = ["orange","pawpaw","apple","banana (small)","watermelon"];
function pick<T>(arr:T[]){ return arr[Math.floor(Math.random()*arr.length)]; }
function oneDay(date: Date){
  return {
    date: date.toISOString().slice(0,10),
    targets: { calories: 2200, protein_g: 130, fiber_g: 30 },
    meals: [
      { name: "Breakfast", items: [ { food: "Oats", portion: "60 g", notes: "cook with water" }, { food: pick(proteins), portion: "25–30 g protein" }, { food: pick(fruits), portion: "1 small" } ]},
      { name: "Lunch", items: [ { food: "Grilled "+pick(["chicken","fish","turkey"]), portion: "150 g" }, { food: pick(carbs), portion: "3/4 cup cooked" }, { food: pick(soups), portion: "1 cup", notes: "light oil" } ]},
      { name: "Dinner", items: [ { food: pick(soups)+" soup with veg", portion: "1–1.5 cups" }, { food: pick(["wheat swallow","eba (small)","brown rice (1/2 cup)"]), portion: "small" }, { food: pick(["fish","eggs","moi-moi"]), portion: "100–120 g or 2 eggs" } ]}
    ],
    snacks: [ { food: pick(snacks), portion: "small" }, { food: pick(["yogurt + chia","groundnuts 25 g","apple + peanuts 1 tbsp"]) } ],
    nudges: ["Aim 7h sleep; wind down 9:30 pm.","If steps < goal by 6:30 pm, take a 10–12 min walk."]
  };
}
export async function POST(){
  const s = await getSession();
  if (!s.user) return NextResponse.json({error:'Unauthorized'},{status:401});
  const start = new Date(); start.setHours(0,0,0,0);
  for (let i=0;i<7;i++){ const d=new Date(start); d.setDate(d.getDate()+i); await prisma.mealPlan.create({ data: { userId: s.user.id, date: d, json: oneDay(d) }}); }
  return NextResponse.redirect(new URL('/app/meal-plans', process.env.NEXT_PUBLIC_APP_URL));
}
