import { NextResponse } from "next/server"; import { getSession } from "@/lib/session";
export async function GET(){ const s=await getSession(); await s.destroy(); return NextResponse.redirect(new URL('/login', process.env.NEXT_PUBLIC_APP_URL)); }
