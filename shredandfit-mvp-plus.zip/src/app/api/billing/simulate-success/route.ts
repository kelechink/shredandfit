import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/session";

export async function POST(req: Request){
  const s = await getSession();
  if (!s.user) return NextResponse.json({error:'Unauthorized'},{status:401});
  const form = await req.formData();
  const plan = (form.get('plan')?.toString() || 'standard').toLowerCase();
  const expiry = new Date(); expiry.setMonth(expiry.getMonth()+1);
  await prisma.user.update({ where: { id: s.user.id }, data: { subscriptionTier: plan, subscriptionExpiry: expiry } });
  return NextResponse.redirect(new URL('/app', process.env.NEXT_PUBLIC_APP_URL));
}
