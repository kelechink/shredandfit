import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/session";

export async function POST(req: Request){
  const s = await getSession();
  if (!s.user || s.user.role !== 'clinician') return NextResponse.json({error:'Unauthorized'},{status:401});
  const form = await req.formData();
  const id = form.get('proposalId')?.toString();
  const action = form.get('action')?.toString();
  if (!id || !action) return NextResponse.json({error:'Invalid'},{status:400});
  await prisma.aIProposal.update({ where: { id }, data: { status: action==='approve'?'approved': action==='reject'?'rejected':'modified', decidedAt: new Date(), clinicianId: s.user.id } });
  return NextResponse.redirect(new URL('/clinician', process.env.NEXT_PUBLIC_APP_URL));
}
