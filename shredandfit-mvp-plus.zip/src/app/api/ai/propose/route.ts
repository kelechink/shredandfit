import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/session";

type Snapshot = {
  weight: { date: string; kg: number }[];
  steps: { date: string; steps: number }[];
  sleep: { date: string; h: number }[];
  meds: { name: string; doseMg: number; freq: string; lastDose?: string }[];
};

export async function POST() {
  const s = await getSession();
  if (!s.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  // snapshot: last 28 days
  const ms = await prisma.measurement.findMany({ where: { userId: s.user.id }, orderBy: { date: 'asc' } });
  const weight = ms.map(m => ({ date: m.date.toISOString().slice(0,10), kg: m.weightKg }));
  const steps = ms.filter(m=>m.steps!=null).map(m => ({ date: m.date.toISOString().slice(0,10), steps: m.steps! }));
  const sleep = ms.filter(m=>m.sleepH!=null).map(m => ({ date: m.date.toISOString().slice(0,10), h: m.sleepH! }));
  const snapshot: Snapshot = { weight, steps, sleep, meds: [] };

  // simple rules: compute 28d % change, propose titration step if tolerating
  const first = weight[0]?.kg, last = weight[weight.length-1]?.kg;
  const delta = (first && last) ? +(last - first).toFixed(1) : 0;
  const pct = (first && last) ? +(((last-first)/first)*100).toFixed(1) : 0;

  const proposal = {
    summary: `Change ${delta} kg (${pct}%) over ${weight.length} entries.`,
    proposedChanges: [
      { type: "reminder", kind: "dose", when: "next Friday 09:00", med: "Tirzepatide", note: "Weekly dose day." },
      { type: "coaching", nudge: "You’re close to your step goal. Try a 10–12 min walk this evening." }
    ],
    flags: pct < -2 ? [] : [{ kind: "slow_loss", note: "Weight loss <2% — consider portion check & step goal +500." }],
    explain: "Protocol: if tolerating and >=4 weeks on dose, consider up-titration; else maintain. (Stub)"
  };

  const row = await prisma.aIProposal.create({ data: { userId: s.user.id, snapshot, proposal } });
  return NextResponse.redirect(new URL('/app/proposals', process.env.NEXT_PUBLIC_APP_URL));
}
