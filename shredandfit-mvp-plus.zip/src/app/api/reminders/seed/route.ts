import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/session";

export async function POST(){
  const s = await getSession();
  if (!s.user) return NextResponse.json({error:'Unauthorized'},{status:401});
  const now = new Date();
  const items = [
    { kind: 'dose', whenAt: new Date(now.getTime()+3600*1000), payload: { med: 'Tirzepatide', doseMg: 2.5 } },
    { kind: 'steps_gap', whenAt: new Date(now.getTime()+8*3600*1000), payload: { target: 6000 } },
    { kind: 'sleep', whenAt: new Date(now.getTime()+12*3600*1000), payload: { message: 'Wind-down 9:30 pm' } },
  ];
  for (const it of items) {
    await prisma.reminder.create({ data: { userId: s.user.id, kind: it.kind, whenAt: it.whenAt, payload: it.payload as any } });
  }
  return NextResponse.redirect(new URL('/app/reminders', process.env.NEXT_PUBLIC_APP_URL));
}
