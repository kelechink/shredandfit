import Link from 'next/link';
const plans = [
  { name: 'Free', plan: 'free', price: '₦0', features: ['Weight tracking', 'Wearable sync (basic)', 'Limited AI tips']},
  { name: 'Standard', plan: 'standard', price: '₦10,000 / mo', features: ['AI meal plans', 'Reminders', 'Analytics']},
  { name: 'Premium', plan: 'premium', price: '₦20,000 / mo', features: ['Clinician review', 'AI dosing proposals', 'Priority support']},
];
export default function Pricing(){
  return(<div className="grid gap-6"><h1 className="text-2xl font-bold">Pricing</h1><div className="grid md:grid-cols-3 gap-6">{plans.map(p=>(<div key={p.name} className="rounded-2xl border bg-white p-6"><h3 className="text-lg font-semibold">{p.name}</h3><div className="text-2xl mt-2">{p.price}</div><ul className="text-sm text-gray-600 mt-3 list-disc pl-5">{p.features.map(f=><li key={f}>{f}</li>)}</ul><Link href={`/subscribe?plan=${p.plan}`} className="mt-4 inline-block rounded-lg bg-black text-white px-4 py-2">Choose {p.name}</Link></div>))}</div></div>);
}
