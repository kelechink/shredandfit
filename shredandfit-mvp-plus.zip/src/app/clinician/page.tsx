import { getSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function ClinicianHome() {
  const s = await getSession();
  if (!s.user || s.user.role !== 'clinician') return <div>Clinician access only.</div>;
  const patients = await prisma.user.findMany({ where: { role: 'patient' }, select: { id: true, email: true, fullName: true } });
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">Clinician Dashboard</h1>
      <ul className="grid gap-2">
        {patients.map(p => <li key={p.id}><Link className="text-blue-600" href={`/clinician/patient/${p.id}`}>{p.fullName || p.email}</Link></li>)}
      </ul>
    </div>
  );
}
