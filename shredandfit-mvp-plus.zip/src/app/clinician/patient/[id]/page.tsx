import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/session';
import WeightChart from '@/components/WeightChart';

export default async function PatientDetail({ params }: { params: { id: string } }) {
  const s = await getSession();
  if (!s.user || s.user.role !== 'clinician') return <div>Clinician access only.</div>;
  const user = await prisma.user.findUnique({ where: { id: params.id } });
  if (!user) return <div>Not found</div>;
  const ms = await prisma.measurement.findMany({ where: { userId: user.id }, orderBy: { date: 'asc' } });
  const prepared = ms.map(m => ({ date: m.date.toISOString().slice(0,10), weightKg: m.weightKg, steps: m.steps || undefined, sleepH: m.sleepH || undefined }));
  const proposals = await prisma.aIProposal.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } });
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">{user.fullName || user.email}</h1>
      <div className="rounded-2xl border bg-white p-4">
        <WeightChart data={prepared} goalWeightKg={105} heightCm={user.heightCm || undefined} />
      </div>
      <div className="grid gap-2">
        <h2 className="font-semibold">AI Proposals</h2>
        {proposals.map(p => (
          <form key={p.id} action="/api/ai/clinician/decision" method="post" className="rounded-2xl border bg-white p-4">
            <input type="hidden" name="proposalId" value={p.id} />
            <pre className="text-sm whitespace-pre-wrap">{JSON.stringify(p.proposal, null, 2)}</pre>
            <div className="mt-2 flex gap-2">
              <button name="action" value="approve" className="rounded-lg border px-3 py-1.5">Approve</button>
              <button name="action" value="reject" className="rounded-lg border px-3 py-1.5">Reject</button>
            </div>
          </form>
        ))}
        {proposals.length===0 && <div className="text-sm text-gray-600">No proposals yet.</div>}
      </div>
    </div>
  );
}
