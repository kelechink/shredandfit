import Link from "next/link";

export default function Home() {
  return (
    <div className="grid gap-8">
      <section className="text-center py-10">
        <h1 className="text-4xl font-extrabold">Lose Weight Smarter. Not Harder.</h1>
        <p className="mt-3 text-gray-600 max-w-2xl mx-auto">AI Doctor, Nigerian meal plans, wearable syncing, medication reminders, and clean progress charts.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Link className="rounded-lg bg-black text-white px-4 py-2" href="/signup">Start Free</Link>
          <Link className="rounded-lg border px-4 py-2" href="/pricing">See Pricing</Link>
        </div>
      </section>
      <section className="grid md:grid-cols-3 gap-6">
        {[
          { title: "AI Doctor", body: "Weekly reviews, reminders, dose proposals (clinician-approved).", href: "/app" },
          { title: "African Meal Plans", body: "Protein-first menus with Nigerian foods.", href: "/app/meal-plans" },
          { title: "Wearables + Charts", body: "Steps, sleep & workouts alongside weight trends.", href: "/app" },
        ].map((c) => (
          <div key={c.title} className="rounded-2xl border bg-white p-5">
            <h3 className="font-semibold text-lg">{c.title}</h3>
            <p className="text-gray-600 mt-1">{c.body}</p>
            <Link className="text-sm mt-2 inline-block text-blue-600" href={c.href}>Open</Link>
          </div>
        ))}
      </section>
    </div>
  );
}
