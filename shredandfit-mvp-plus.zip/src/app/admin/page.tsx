import { getSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';

export default async function AdminHome() {
  const s = await getSession();
  if (!s.user || s.user.role !== 'admin') return <div>Admin access only.</div>;
  const users = await prisma.user.findMany({ orderBy: { createdAt: 'desc' } });
  const products = await prisma.product.findMany({});
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">Admin Console</h1>
      <div className="rounded-2xl border bg-white p-4">
        <h2 className="font-semibold">Users</h2>
        <ul className="text-sm">{users.map(u => <li key={u.id}>{u.email} — {u.role} — {u.subscriptionTier}</li>)}</ul>
      </div>
      <div className="rounded-2xl border bg-white p-4">
        <h2 className="font-semibold">Products</h2>
        <ul className="text-sm">{products.map(p => <li key={p.id}>{p.name} — {p.type} — {p.active ? 'active' : 'inactive'}</li>)}</ul>
      </div>
    </div>
  );
}
