import { getSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function Proposals() {
  const session = await getSession();
  if (!session.user) return <div>Please login.</div>;
  const items = await prisma.aIProposal.findMany({ where: { userId: session.user.id }, orderBy: { createdAt: 'desc' } });
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">AI Proposals</h1>
      {items.map(p => (
        <div key={p.id} className="rounded-2xl border bg-white p-4">
          <div className="text-sm text-gray-500">Status: {p.status}</div>
          <pre className="mt-2 text-sm whitespace-pre-wrap">{JSON.stringify(p.proposal, null, 2)}</pre>
        </div>
      ))}
      {items.length===0 && <div className="text-sm text-gray-600">No proposals yet.</div>}
    </div>
  );
}
