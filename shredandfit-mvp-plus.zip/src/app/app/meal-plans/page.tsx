import { getSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function MealPlans() {
  const session = await getSession();
  if (!session.user) return <div>Please <Link href="/login" className="text-blue-600">log in</Link>.</div>;

  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  const active = user?.subscriptionTier !== 'free' && (!user?.subscriptionExpiry || user.subscriptionExpiry > new Date());

  if (!active) {
    return <div className="rounded-2xl border bg-white p-6"><h1 className="text-xl font-semibold">Premium feature</h1><p className="text-gray-600">Upgrade to Standard or Premium to generate AI meal plans.</p><Link href="/pricing" className="mt-3 inline-block rounded-lg bg-black text-white px-4 py-2">See pricing</Link></div>;
  }

  const plans = await prisma.mealPlan.findMany({ where: { userId: session.user.id }, orderBy: { date: 'desc' }, take: 7 });
  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Meal Plans</h1>
        <form action="/api/mealplans/generate" method="post">
          <button className="rounded-lg bg-black text-white px-4 py-2">Generate New (7 days)</button>
        </form>
      </div>
      {plans.length===0 && <div className="text-sm text-gray-600">No plans yet. Generate your first plan.</div>}
      <div className="grid gap-4">
        {plans.map((p) => (
          <details key={p.id} className="rounded-2xl border bg-white p-4">
            <summary className="font-semibold">{new Date(p.date).toDateString()}</summary>
            <pre className="mt-3 text-sm whitespace-pre-wrap">{JSON.stringify(p.json, null, 2)}</pre>
          </details>
        ))}
      </div>
    </div>
  );
}
