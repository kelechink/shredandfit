import { getSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function Reminders(){
  const s = await getSession();
  if (!s.user) return <div>Please login.</div>;
  const rows = await prisma.reminder.findMany({ where: { userId: s.user.id }, orderBy: { whenAt: 'asc' } });
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-bold">Reminders</h1>
      {rows.map(r => (
        <div key={r.id} className="rounded-2xl border bg-white p-4">
          <div className="text-sm text-gray-600">{r.kind} — {new Date(r.whenAt).toLocaleString()}</div>
          <pre className="text-xs whitespace-pre-wrap mt-1">{JSON.stringify(r.payload, null, 2)}</pre>
        </div>
      ))}
      {rows.length===0 && <div className="text-sm text-gray-600">No reminders yet. Use the dashboard to seed examples.</div>}
    </div>
  );
}
