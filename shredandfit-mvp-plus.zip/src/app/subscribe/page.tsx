import { getSession } from '@/lib/session';
import Link from 'next/link';
export default async function Subscribe({ searchParams }:{ searchParams: { plan?: string } }){
  const s = await getSession();
  const plan = searchParams.plan ?? 'standard';
  if (!s.user) return <div>Please <Link className="text-blue-600" href="/login">log in</Link>.</div>;
  return (<div className="max-w-md mx-auto bg-white border rounded-2xl p-6"><h1 className="text-xl font-semibold">Subscribe to {plan}</h1><p className="text-sm text-gray-600">Paystack integration scaffold. Replace simulator with real checkout.</p><form action="/api/billing/simulate-success" method="post" className="mt-4 grid gap-2"><input type="hidden" name="plan" value={plan}/><button className="rounded-lg bg-black text-white px-4 py-2">Simulate Payment Success</button></form><Link href="/pricing" className="text-sm inline-block mt-3">Back to pricing</Link></div>);
}
