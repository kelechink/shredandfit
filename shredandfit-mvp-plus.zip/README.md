# ShredAndFit — MVP Plus

This is a more complete scaffold for the full application:

- ✅ App (patient) with weight chart, reminders, meal plans
- ✅ AI Doctor proposals (rules stub) + clinician approval flow
- ✅ Clinician dashboard (patients list, detail, approve/reject)
- ✅ Admin console (users + products view)
- ✅ Subscriptions (simulator; replace with Paystack/Flutterwave)
- ✅ Wearables stubs (to implement using Google Fit/Fitbit/Apple Health app flows)
- ✅ Products & protocols tables (for meds/supplements/devices)
- ✅ WooCommerce/WordPress SSO bridge placeholders

## Quick Start

```bash
npm install
cp .env.example .env
npm run prisma:push
npm run dev
```

Open http://localhost:3000

- Sign up → /app
- Add measurements → see charts
- Subscribe (simulator) → /subscribe
- Generate meal plans → /app/meal-plans
- Create AI proposal → /app → "Generate Weekly Review" → review under /app/proposals
- (Clinician) manually set your user role to clinician in DB via `prisma studio`, then open /clinician

## Production To-Dos
- Integrate real Paystack/Flutterwave checkout + webhooks
- Add email verification and rate limits
- Implement wearable connectors: app-side for HealthKit, OAuth for Google Fit/Fitbit
- Secure role assignment + clinician verification
- Host on Vercel (web) + managed Postgres (Neon/Render) + object storage (S3 compatible)
