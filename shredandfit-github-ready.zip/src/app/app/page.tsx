import Link from 'next/link'; import { prisma } from '@/lib/prisma'; import { getSession } from '@/lib/session'; import WeightChart from '@/components/WeightChart';
export const dynamic = 'force-dynamic';
export default async function AppPage(){ const s=await getSession(); if(!s.user) return <div>Please <Link className="text-blue-600" href="/login">log in</Link>.</div>;
  const ms = await prisma.measurement.findMany({ where: { userId: s.user.id }, orderBy: { date: 'asc' } });
  const data = ms.map(m => ({ date: m.date.toISOString().slice(0,10), weightKg: m.weightKg, steps: m.steps||undefined, sleepH: m.sleepH||undefined }));
  return (<div className="grid gap-6">
    <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Your Dashboard</h1><div className="flex gap-2"><a className="rounded-lg border px-3 py-1.5" href="/api/auth/logout">Logout</a><Link className="rounded-lg bg-black text-white px-3 py-1.5" href="/app/meal-plans">Meal Plans</Link></div></div>
    <div className="rounded-2xl border bg-white p-4">
      <h2 className="font-semibold mb-2">Weight</h2>
      <WeightChart data={data} goalWeightKg={105} heightCm={173} />
      <form action="/api/measurements" method="post" className="grid md:grid-cols-4 gap-2 mt-3">
        <input className="border rounded-lg px-3 py-2" type="date" name="date" required />
        <input className="border rounded-lg px-3 py-2" type="number" step="0.1" name="weightKg" placeholder="Weight (kg)" required />
        <input className="border rounded-lg px-3 py-2" type="number" name="steps" placeholder="Steps" />
        <input className="border rounded-lg px-3 py-2" type="number" step="0.1" name="sleepH" placeholder="Sleep (h)" />
        <button className="rounded-lg bg-black text-white px-4 py-2 md:col-span-4">Save</button>
      </form>
    </div>
    <div className="grid md:grid-cols-3 gap-4">
      <div className="rounded-2xl border bg-white p-4"><h3 className="font-semibold">AI Doctor</h3><form action="/api/ai/propose" method="post"><button className="mt-2 rounded-lg border px-3 py-1.5">Generate Weekly Review</button></form><Link className="text-blue-600 text-sm block mt-2" href="/app/proposals">View proposals</Link></div>
      <div className="rounded-2xl border bg-white p-4"><h3 className="font-semibold">Subscription</h3><p className="text-sm text-gray-600">Upgrade to unlock AI meal plans & reminders.</p><Link className="mt-2 inline-block rounded-lg border px-3 py-1.5" href="/pricing">View plans</Link></div>
      <div className="rounded-2xl border bg-white p-4"><h3 className="font-semibold">Meal Plans</h3><Link className="mt-2 inline-block rounded-lg border px-3 py-1.5" href="/app/meal-plans">Open</Link></div>
    </div>
  </div>); }
