import Link from "next/link";
export default function Home(){
  return (<div className="grid gap-8">
    <section className="text-center py-10">
      <h1 className="text-4xl font-extrabold">Lose Weight Smarter. Not Harder.</h1>
      <p className="mt-3 text-gray-600 max-w-2xl mx-auto">AI Doctor, Nigerian meal plans, wearable syncing, medication reminders, and progress charts.</p>
      <div className="mt-6 flex justify-center gap-3">
        <Link className="rounded-lg bg-black text-white px-4 py-2" href="/signup">Start Free</Link>
        <Link className="rounded-lg border px-4 py-2" href="/pricing">See Pricing</Link>
      </div>
    </section>
  </div>);
}
