import "./globals.css"; import Link from "next/link";
export const metadata = { title: "ShredAndFit", description: "AI-powered weight loss" };
export default function RootLayout({ children }: { children: React.ReactNode }){
  return (<html lang="en"><body className="min-h-screen bg-gray-50 text-gray-900">
    <header className="border-b bg-white"><div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
      <Link href="/" className="font-bold text-xl">ShredAndFit</Link>
      <nav className="flex gap-4 text-sm">
        <Link href="/pricing">Pricing</Link>
        <Link href="/app">App</Link>
        <Link href="/login" className="font-semibold">Login</Link>
        <Link href="/signup" className="rounded-lg bg-black text-white px-3 py-1.5">Get Started</Link>
      </nav>
    </div></header>
    <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
    <footer className="border-t mt-10 py-6 text-center text-sm text-gray-500">&copy; {new Date().getFullYear()} ShredAndFit</footer>
  </body></html>);
}
