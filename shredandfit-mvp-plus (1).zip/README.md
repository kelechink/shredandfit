# ShredAndFit — MVP Plus (Compact)

Next.js + Prisma + iron-session + Recharts. Includes:
- Auth (email/password)
- Weight chart (with steps/sleep fields)
- Meal-plan generator (Nigerian foods, 7 days)
- AI proposals (stub) page
- Pricing + subscribe (simulator)

## Local
```bash
npm install
cp .env.example .env
npm run prisma:push
npm run dev
# open http://localhost:3000
```
